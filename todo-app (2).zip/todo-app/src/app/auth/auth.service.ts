import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { TosterService } from '../shared/service/toster.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public loggedIn = false;

  constructor(private readonly http: HttpClient, private router: Router,
    private tosterService: TosterService
  ) { }

  login(username: string, password: string) {
    this.http.post("http://localhost:9898/auth/token", { username, password }).subscribe({
      next: (result: any) => {
        this.loggedIn = true;
        localStorage.setItem('authToken', result);
        this.router.navigate(['task']);
      },
      error: (error) => {
        this.loggedIn = true;
        this.tosterService.showError("An error occurred during login. Please try again later.");
        localStorage.setItem('authToken', error.text);
      }
    })
  }

  logout() {
    this.loggedIn = false;
    localStorage.removeItem('authToken');
  }

  isLoggedIn(): boolean {
    return this.loggedIn || !!localStorage.getItem('authToken');
  }
}
