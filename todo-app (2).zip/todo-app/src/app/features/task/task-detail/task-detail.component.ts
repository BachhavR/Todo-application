import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskHttpService } from '../service/task-http.service';
import { formatDate } from '@angular/common';
import { TosterService } from '../../../shared/service/toster.service';

export interface Task {
  taskName: string,
  description: string,
  startDate: string,
  endDate: string,
  status: string,
  totalEffort: number
}

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrl: './task-detail.component.scss'
})
export class TaskDetailComponent implements OnInit {
  public optionList: string[] = ['NEW', 'IN PROGRESS', 'COMPLETED'];
  public taskDetails: any = {};
  constructor(private router: Router, private route: ActivatedRoute,
    private taskHttpService: TaskHttpService, private tosterService: TosterService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.getTaskDetails(params['id']);
    });
  }

  getTaskDetails(taskId: number) {
    this.taskHttpService.getTaskDetail(taskId).subscribe({
      next: (task) => {
        this.taskDetails = task;
      },
      error: (error: any) => {
        this.taskDetails = undefined;
        this.tosterService.showError("Error fetching task. Please try again later.");
      }
    });
  }

  onChange(event: any): void {
    const requestObj = {
      ...this.taskDetails,
      startDate: formatDate(this.taskDetails.startDate, "yyyy-MM-ddTHH:mm:ss", "en"),
      endDate: formatDate(this.taskDetails.endDate, "yyyy-MM-ddTHH:mm:ss", "en"),
      status: event.target.value
    };
    this.taskHttpService.updateStatus(requestObj).subscribe({
      next: (response: any) => {
        this.getTaskDetails(requestObj?.id);
        this.tosterService.showSuccess("Task updated successfully!");
      },
      error: (error: any) => {
        this.tosterService.showError("Error updating task. Please try again later.");
      }
    });
  }

  onTaskList() {
    this.router.navigate(['list']);
  }
  onAddNewTask() {
    this.router.navigate(['add-task']);
  }

}
