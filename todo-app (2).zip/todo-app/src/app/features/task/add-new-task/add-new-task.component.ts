import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskHttpService } from '../service/task-http.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-new-task',
  templateUrl: './add-new-task.component.html',
  styleUrl: './add-new-task.component.scss'
})
export class AddNewTaskComponent implements OnInit {
  public taskForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private taskHttpService: TaskHttpService) { }

  ngOnInit(): void {
    this.taskForm = this.fb.group({
      taskName: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(5)]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      totalEffort: ['', [Validators.required, Validators.pattern('^[0-9]*$')]] // Only numbers
    });
  }

  // Submit the form
  onSubmit(): void {
    if (this.taskForm.valid) {
      const addTaskRequest = { ...this.taskForm.value, status: "NEW" };
      addTaskRequest.startDate = formatDate(addTaskRequest.startDate, "yyyy-MM-ddThh:mm:ss", 'en');
      addTaskRequest.endDate = formatDate(addTaskRequest.endDate, "yyyy-MM-ddThh:mm:ss", 'en');
      addTaskRequest.totalEffort = parseInt(addTaskRequest.totalEffort);
      this.taskHttpService.addNewtask(addTaskRequest);
    } else {
      console.log('Form is invalid');
      this.taskForm.markAllAsTouched(); // Show validation errors
    }
  }

  onCancle() {
    this.router.navigate(['list']);
  }

  // Getter for easy access to form controls
  get f() {
    return this.taskForm.controls;
  }
}
