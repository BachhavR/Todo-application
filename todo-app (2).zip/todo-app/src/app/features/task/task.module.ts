import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskComponent } from './task.component';
import { RouterModule, Routes } from '@angular/router';
import { TaskListComponent } from './task-list/task-list.component';
import { TaskDetailComponent } from './task-detail/task-detail.component';
import { AgGridAngular } from 'ag-grid-angular';
import { AuthGuard } from '../../auth/auth.guard';
import { AddNewTaskComponent } from './add-new-task/add-new-task.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from '../../interceptors/auth.interceptor';
import { HyperlinkComponent } from './task-list/hyperlink/hyperlink.component';

const routes: Routes = [
  {
    path: '',
    component: TaskComponent,
    children: [
      { path: '', redirectTo: 'list', pathMatch: 'full' },  // Default child route
      { path: 'list', component: TaskListComponent },
      { path: 'add-task', component: AddNewTaskComponent, canActivate: [AuthGuard] },
      { path: ':id', component: TaskDetailComponent },
    ]
  }
];


@NgModule({
  declarations: [
    TaskComponent,
    TaskListComponent,
    TaskDetailComponent,
    AddNewTaskComponent,
    HyperlinkComponent,
  ],
  imports: [
    CommonModule,
    AgGridAngular,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ]
})
export class TaskModule { }
