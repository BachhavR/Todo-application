import { Component } from '@angular/core';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-hyperlink',
  templateUrl: './hyperlink.component.html',
  styleUrl: './hyperlink.component.scss'
})
export class HyperlinkComponent {
  public params: ICellRendererParams | undefined;

  refresh(params: ICellRendererParams) {
    return false;
  }

  agInit(params: ICellRendererParams) {
    this.params = params;
    console.log(this.params);
  }
}
