import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class TosterService {

  constructor(private toastrService: ToastrService) {
  }
  
  public showSuccess(message: string): void {
    this.toastrService.success(message, 'Title Success!');
  }

  public showInfo(message: string): void {
    this.toastrService.info(message, 'Title Info!');
  }

  public showWarning(message: string): void {
    this.toastrService.warning(message, 'Title Warning!');
  }

  public showError(message: string): void {
    this.toastrService.error(message, 'Title Error!');
  }
}
