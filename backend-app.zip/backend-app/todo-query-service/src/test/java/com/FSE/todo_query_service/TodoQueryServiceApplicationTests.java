package com.FSE.todo_query_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoQueryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
