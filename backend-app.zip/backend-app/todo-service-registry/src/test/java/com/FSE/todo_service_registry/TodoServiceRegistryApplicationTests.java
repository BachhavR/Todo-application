package com.FSE.todo_service_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
