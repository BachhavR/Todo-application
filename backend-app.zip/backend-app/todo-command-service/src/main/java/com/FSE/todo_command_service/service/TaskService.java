package com.FSE.todo_command_service.service;


import com.FSE.todo_command_service.entity.Task;
import com.FSE.todo_command_service.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    public Task createTask(Task task) {
        validateTask(task);
        return taskRepository.save(task);
    }

    private void validateTask(Task task) {
        if (task.getTotalEffort() <= 0) {
            throw new IllegalArgumentException("Total effort required must be greater than 0.");
        }
        if (task.getTaskName() == null || task.getDescription() == null || task.getStatus() == null) {
            throw new IllegalArgumentException("All fields are mandatory.");
        }
        if (task.getEndDate().isBefore(task.getStartDate())) {
            throw new IllegalArgumentException("Task end date must be greater than task start date.");
        }
    }

    public Task updateTaskStatus(Long id) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new RuntimeException("Task not found"));
        if (task.getEndDate().isBefore(LocalDateTime.now())) {
            task.setStatus("PENDING");
        } else {
            task.setStatus("COMPLETED");
        }
        return taskRepository.save(task);
    }
}