import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { TosterService } from '../../../shared/service/toster.service';

@Injectable({
  providedIn: 'root'
})
export class TaskHttpService {

  constructor(private router: Router, private readonly http: HttpClient,
    private tosterService: TosterService
  ) { }

  addNewtask(addTaskRequest: any) {
    this.http.post("http://localhost:8081/api/tasks", addTaskRequest).subscribe({
      next: (result: any) => {
        this.tosterService.showSuccess("Task created successfully!");
        this.router.navigate(['task/list']);
      }, error: (error) => {
        console.log(error);
        this.tosterService.showError("Error creating task. Please try again later.");
      }
    })
  }

  getTaskList() {
    return this.http.get("http://localhost:8082/taskQueryService/getAll");
  }

  getTaskDetail(taskId: number) {
    return this.http.get(`http://localhost:8082/taskQueryService/${taskId}`);
  }
  updateStatus(taskDetail: any) {
    return this.http.put(`http://localhost:8081/api/tasks/${taskDetail?.id}`, taskDetail);
  }
}
