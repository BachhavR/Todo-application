import { Component, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community'; // Column Definition Type Interface
import { Router } from '@angular/router';
import { HyperlinkComponent } from './hyperlink/hyperlink.component';
import { TaskHttpService } from '../service/task-http.service';
import { TASK_COL_DEFS } from './task.constant';
import { TosterService } from '../../../shared/service/toster.service';
interface Task {
  id: number,
  taskName: string;
  description: string;
  startDate: string;
  endDate: string;
  status: string;
  totalEffort: number;
}

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit {
  public rowData: Task[] = [];
  public colDefs: ColDef[] = TASK_COL_DEFS;

  constructor(private router: Router, private taskHttpService: TaskHttpService,
    private tosterService: TosterService
  ) { }

  ngOnInit(): void {
    this.taskHttpService.getTaskList().subscribe({
      next: (result: any) => {
        this.rowData = result;
      }, error: (error: any) => {
        this.tosterService.showError("Error fetching task. Please try again later.");
      }
    })
  }

  addNewTask() {
    this.router.navigate(['add-task']);
  }
}
