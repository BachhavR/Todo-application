import { HyperlinkComponent } from "./hyperlink/hyperlink.component";

export const TASK_COL_DEFS = [
    { field: "id", maxWidth: 80, cellRenderer: HyperlinkComponent },
    { field: "taskName", maxWidth: 150 },
    { field: "description", flex: 1, suppressSizeToFit: true },
    { field: "startDate", maxWidth: 120 },
    { field: "endDate", maxWidth: 120 },
    { field: "status", maxWidth: 120 },
    { field: "totalEffort", maxWidth: 100 },
];