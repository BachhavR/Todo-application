import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-new-task',
  templateUrl: './add-new-task.component.html',
  styleUrl: './add-new-task.component.scss'
})
export class AddNewTaskComponent {
  public taskForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {}

  ngOnInit(): void {
    // Initialize the form with validation rules
    this.taskForm = this.fb.group({
      taskName: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(5)]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      // status: ['', Validators.required],
      totalEfforts: ['', [Validators.required, Validators.pattern('^[0-9]*$')]] // Only numbers
    });
  }

  // Submit the form
  onSubmit(): void {
    if (this.taskForm.valid) {
      console.log('Form submitted successfully', this.taskForm.value);
      this.router.navigate(['task-list']);
    } else {
      console.log('Form is invalid');
      this.taskForm.markAllAsTouched(); // Show validation errors
    }
  }

  // Getter for easy access to form controls
  get f() {
    return this.taskForm.controls;
  }
}
