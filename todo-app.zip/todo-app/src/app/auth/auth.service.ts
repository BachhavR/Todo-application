// src/app/auth/auth.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = false;

  login(username: string, password: string): boolean {
    // Simulating authentication logic
    if (username === 'user' && password === 'password') {
      this.loggedIn = true;
      localStorage.setItem('authToken', 'fake-jwt-token');
      return true;
    }
    return false;
  }

  logout() {
    this.loggedIn = false;
    localStorage.removeItem('authToken');
  }

  isLoggedIn(): boolean {
    return this.loggedIn || !!localStorage.getItem('authToken');
  }
}
