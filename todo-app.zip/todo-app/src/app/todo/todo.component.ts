// src/app/todo/todo.component.ts
import { Component } from '@angular/core';
import { Todo, TodoService } from './todo.service';
import { ColDef, ISelectCellEditorParams } from 'ag-grid-community'; // Column Definition Type Interface
import { Router } from '@angular/router';
interface Task {
  taskName: string;
  description: string;
  startDate: string;
  endDate: string;
  status: string;
  totalEfforts: number;
}

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss']
})
export class TodoComponent {
  todos: Todo[] = [];
  newTask = '';
 // Row Data: The data to be displayed.
 public rowData = [
  { taskName: "Tesla", description: "Model Y fsdfsdfasdf sdfsdfsdf dfdsfs", startDate: 64950, endDate: 123445, status: "Pending", totalEffort: 13 },
  { taskName: "Ford", description: "F-Series", startDate: 33850, endDate: 123445, status: "Completed", totalEffort: 3 },
  { taskName: "Toyota", description: "Corolla", startDate: 29600, endDate: 123445, status: "Pending", totalEffort: 2 },
];

languages = ["English", "Spanish", "French", "Portuguese", "(other)"];

// Column Definitions: Defines the columns to be displayed.
public colDefs: ColDef[] = [
  { field: "taskName", maxWidth: 150 },
  { field: "description", flex: 1, suppressSizeToFit: true },
  { field: "startDate", maxWidth: 120 },
  { field: "endDate", maxWidth: 120 },
  { field: "status", maxWidth: 120 },
  { field: "totalEffort", maxWidth: 150 },
  { field: "action", maxWidth: 120,  cellRenderer: (invNum: any) => 
    `<a href="javascript:void(0)">${invNum.data.status}</a>` },
];

  constructor(private todoService: TodoService, private router: Router) {
    this.todos = this.todoService.getTodos();
  }

  addTask() {
    if (this.newTask) {
      this.todoService.addTodo(this.newTask);
      this.newTask = '';
    }
  }

  modifyTask(id: number) {
    const newTask = prompt('Enter new task:');
    if (newTask) {
      this.todoService.modifyTodo(id, newTask);
    }
  }

    // Method to change the status of a task
    changeStatus(task: Task, newStatus: string): void {
      task.status = newStatus;
    }

    addNewTask() {
      this.router.navigate(['add-task']);
    }
}
