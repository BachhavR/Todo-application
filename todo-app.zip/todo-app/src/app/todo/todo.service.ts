// src/app/todo/todo.service.ts
import { Injectable } from '@angular/core';

export interface Todo {
  id: number;
  task: string;
}

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private todos: Todo[] = [];
  private nextId = 1;

  getTodos(): Todo[] {
    return this.todos;
  }

  addTodo(task: string) {
    this.todos.push({ id: this.nextId++, task });
  }

  modifyTodo(id: number, task: string) {
    const todo = this.todos.find(t => t.id === id);
    if (todo) {
      todo.task = task;
    }
  }
}
